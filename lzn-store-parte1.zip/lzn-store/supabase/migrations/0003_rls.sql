-- Habilita RLS em todas as tabelas. Sem política = sem acesso.
alter table public.profiles enable row level security;
alter table public.admin_users enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_variants enable row level security;
alter table public.product_images enable row level security;
alter table public.suppliers enable row level security;
alter table public.supplier_products enable row level security;
alter table public.customers enable row level security;
alter table public.addresses enable row level security;
alter table public.coupons enable row level security;
alter table public.coupon_usages enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.shipments enable row level security;
alter table public.store_settings enable row level security;
alter table public.audit_logs enable row level security;

-- profiles: o usuário lê e edita o próprio perfil; admin lê todos.
create policy profiles_select_own on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy profiles_update_own on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- admin_users: somente leitura da própria linha. Escrita só via SQL/service role.
create policy admin_users_select_own on public.admin_users for select using (user_id = auth.uid());

-- Catálogo: leitura pública do que está ativo; escrita só admin.
create policy categories_public_read on public.categories for select using (is_active or public.is_admin());
create policy categories_admin_write on public.categories for all using (public.is_admin()) with check (public.is_admin());

create policy products_public_read on public.products for select using (is_active or public.is_admin());
create policy products_admin_write on public.products for all using (public.is_admin()) with check (public.is_admin());

create policy variants_public_read on public.product_variants for select using (
  public.is_admin() or exists (select 1 from public.products p where p.id = product_id and p.is_active));
create policy variants_admin_write on public.product_variants for all using (public.is_admin()) with check (public.is_admin());

create policy images_public_read on public.product_images for select using (
  public.is_admin() or exists (select 1 from public.products p where p.id = product_id and p.is_active));
create policy images_admin_write on public.product_images for all using (public.is_admin()) with check (public.is_admin());

-- Fornecedores e custos: só admin (custo nunca é público).
create policy suppliers_admin on public.suppliers for all using (public.is_admin()) with check (public.is_admin());
create policy supplier_products_admin on public.supplier_products for all using (public.is_admin()) with check (public.is_admin());

-- Clientes e endereços.
create policy customers_select_own on public.customers for select using (user_id = auth.uid() or public.is_admin());
create policy customers_update_own on public.customers for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy customers_admin_write on public.customers for all using (public.is_admin()) with check (public.is_admin());

create policy addresses_own_all on public.addresses for all
  using (exists (select 1 from public.customers c where c.id = customer_id and c.user_id = auth.uid()))
  with check (exists (select 1 from public.customers c where c.id = customer_id and c.user_id = auth.uid()));
create policy addresses_admin_read on public.addresses for select using (public.is_admin());

-- Cupons: sem leitura pública (validação é feita no servidor com service role).
create policy coupons_admin on public.coupons for all using (public.is_admin()) with check (public.is_admin());
create policy coupon_usages_admin_read on public.coupon_usages for select using (public.is_admin());

-- Pedidos: cliente lê os próprios; admin lê e atualiza. Criação só pelo servidor (service role).
create policy orders_select_own on public.orders for select using (
  public.is_admin() or exists (select 1 from public.customers c where c.id = customer_id and c.user_id = auth.uid()));
create policy orders_admin_update on public.orders for update using (public.is_admin()) with check (public.is_admin());

-- order_items: o cliente NÃO vê cost_cents. Por isso a leitura do cliente passa pela view abaixo.
create policy order_items_admin_all on public.order_items for all using (public.is_admin()) with check (public.is_admin());

create view public.my_order_items with (security_invoker = false) as
  select oi.id, oi.order_id, oi.product_id, oi.variant_id, oi.product_name, oi.variant_name,
         oi.sku, oi.image_url, oi.unit_price_cents, oi.quantity
  from public.order_items oi
  join public.orders o on o.id = oi.order_id
  join public.customers c on c.id = o.customer_id
  where c.user_id = auth.uid();
grant select on public.my_order_items to authenticated;

create policy payments_select_own on public.payments for select using (
  public.is_admin() or exists (
    select 1 from public.orders o join public.customers c on c.id = o.customer_id
    where o.id = order_id and c.user_id = auth.uid()));
create policy payments_admin_update on public.payments for update using (public.is_admin()) with check (public.is_admin());

create policy shipments_select_own on public.shipments for select using (
  public.is_admin() or exists (
    select 1 from public.orders o join public.customers c on c.id = o.customer_id
    where o.id = order_id and c.user_id = auth.uid()));
create policy shipments_admin_write on public.shipments for all using (public.is_admin()) with check (public.is_admin());

-- Configurações: só as marcadas como públicas são legíveis; escrita só admin.
create policy settings_public_read on public.store_settings for select using (is_public or public.is_admin());
create policy settings_admin_write on public.store_settings for all using (public.is_admin()) with check (public.is_admin());

-- Auditoria: só admin lê. Inserção pelo servidor.
create policy audit_admin_read on public.audit_logs for select using (public.is_admin());

-- Storage: leitura pública do bucket, escrita só admin.
create policy product_images_public_read on storage.objects for select using (bucket_id = 'product-images');
create policy product_images_admin_insert on storage.objects for insert with check (bucket_id = 'product-images' and public.is_admin());
create policy product_images_admin_update on storage.objects for update using (bucket_id = 'product-images' and public.is_admin());
create policy product_images_admin_delete on storage.objects for delete using (bucket_id = 'product-images' and public.is_admin());
