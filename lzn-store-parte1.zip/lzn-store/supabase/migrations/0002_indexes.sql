create index idx_products_category on public.products (category_id);
create index idx_products_active on public.products (is_active, created_at desc);
create index idx_products_featured on public.products (is_featured) where is_featured;
create index idx_products_best_seller on public.products (sales_count desc) where is_active;
create index idx_products_search on public.products
  using gin (to_tsvector('portuguese', name || ' ' || description));
create index idx_variants_product on public.product_variants (product_id);
create index idx_images_product on public.product_images (product_id, sort_order);
create index idx_categories_parent on public.categories (parent_id);
create index idx_supplier_products_variant on public.supplier_products (variant_id);
create index idx_customers_email on public.customers (lower(email));
create index idx_addresses_customer on public.addresses (customer_id);
create index idx_orders_customer on public.orders (customer_id, created_at desc);
create index idx_orders_status on public.orders (status, created_at desc);
create index idx_orders_supplier on public.orders (supplier_id);
create index idx_order_items_order on public.order_items (order_id);
create index idx_payments_order on public.payments (order_id);
create index idx_coupon_usages_coupon_customer on public.coupon_usages (coupon_id, customer_id);
create index idx_audit_created on public.audit_logs (created_at desc);
