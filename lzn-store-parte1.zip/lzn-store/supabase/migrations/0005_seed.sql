-- Configurações iniciais. Edite os valores no painel depois.
insert into public.store_settings (key, value, is_public) values
  ('store_name', '"LZN STORE"', true),
  ('support_email', '""', true),
  ('support_whatsapp', '""', true),
  ('free_shipping_min_cents', '0', true),
  ('flat_shipping_cents', '0', true)
on conflict (key) do nothing;

-- PRIMEIRO ADMINISTRADOR (execute manualmente após criar sua conta pelo site):
-- insert into public.admin_users (user_id)
--   select id from auth.users where email = 'SEU_EMAIL_AQUI';
