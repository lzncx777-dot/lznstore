-- Resgate atômico de cupom: evita estourar max_uses com pedidos simultâneos.
create or replace function public.redeem_coupon(p_coupon_id uuid, p_order_id uuid, p_customer_id uuid, p_discount_cents integer)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_coupon public.coupons%rowtype; v_customer_uses integer;
begin
  select * into v_coupon from public.coupons where id = p_coupon_id for update;
  if not found or not v_coupon.is_active then return false; end if;
  if v_coupon.max_uses is not null and v_coupon.used_count >= v_coupon.max_uses then return false; end if;
  select count(*) into v_customer_uses from public.coupon_usages
    where coupon_id = p_coupon_id and customer_id = p_customer_id;
  if v_customer_uses >= v_coupon.max_uses_per_customer then return false; end if;
  insert into public.coupon_usages (coupon_id, order_id, customer_id, discount_cents)
    values (p_coupon_id, p_order_id, p_customer_id, p_discount_cents);
  update public.coupons set used_count = used_count + 1 where id = p_coupon_id;
  return true;
end $$;

-- Marca o pedido como pago de forma idempotente (chamado pelo webhook).
create or replace function public.mark_order_paid(p_order_id uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_updated integer;
begin
  update public.orders set status = 'paid', paid_at = now()
    where id = p_order_id and status = 'pending_payment';
  get diagnostics v_updated = row_count;
  if v_updated > 0 then
    update public.products p set sales_count = p.sales_count + oi.quantity
      from public.order_items oi where oi.order_id = p_order_id and oi.product_id = p.id;
  end if;
  return v_updated > 0;
end $$;

-- Funções sensíveis só podem ser chamadas pelo servidor (service role).
revoke all on function public.redeem_coupon(uuid, uuid, uuid, integer) from public, anon, authenticated;
revoke all on function public.mark_order_paid(uuid) from public, anon, authenticated;
grant execute on function public.redeem_coupon(uuid, uuid, uuid, integer) to service_role;
grant execute on function public.mark_order_paid(uuid) to service_role;
